def milespergallon(miles, gallons):
  return miles / gallons
def Cost(gallons):
  cost = gallons * 2.5
  return cost
  
destinationcity = input("Enter destination city:")
milestraveled = int(input("Miles traveled?:"))
gallons = int(input("gallons used for a trip:"))
milespergallon = milespergallon(milestraveled, gallons)
cost = Cost(gallons)

print("To ",destinationcity," miles you traveled ",milestraveled," gas cost is:",cost)
