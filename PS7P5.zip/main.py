def compute_Tuition(dis,ch):
  if dis =='I':
    return ch*250
  elif dis =='O':
    return ch*550

lastname = input("Enter your last name:")
credithours = int(input("Enter credit hours"))
districtcode = input("Enter district code:")
tuition = compute_Tuition(districtcode,credithours)

print(lastname," your tuition fee is: ",tuition)
