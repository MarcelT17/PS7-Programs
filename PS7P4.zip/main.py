def pay_rate(jobcode):
  if jobcode == 'L':
    return 25
  elif jobcode == 'A':
    return 30
  elif jobcode == 'J':
    return 50

def grosspay(hw,pr):
  return workinghours * payrate

lastname = input("Enter your lastname:")
jobcode = input("Enter your jobcode:")
workinghours = int(input("Enter your working hours:"))
payrate = pay_rate(jobcode)
Grosspay = grosspay(workinghours, payrate)

print(lastname, " your gross pay is :",Grosspay)
