def battingaverage(numberofhits,bats):
  return numberofhits/bats
  
lastname = input("Enter last name:")
numberofhits = int(input("number of hits?:"))
bats = int(input("bats at a keyboard:"))
battingaverage = battingaverage(numberofhits,bats)

print("To ",lastname," number of hits ",numberofhits," batting average is:",)